@echo off
chcp 65001 >nul
set "ROOT=%~dp0"

"%ROOT%bin\LyricsTrayBlocker.exe" stop
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process PowerShell -Verb RunAs -Wait -ArgumentList '-NoProfile -ExecutionPolicy Bypass -Command ""Unregister-ScheduledTask -TaskName LyricsTrayNativeHook -Confirm:$false -ErrorAction SilentlyContinue; Remove-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Run -Name LyricsTrayNativeHook -Force -ErrorAction SilentlyContinue""'"
powershell -NoProfile -ExecutionPolicy Bypass -File "%ROOT%uninstall-task.ps1"
"%ROOT%bin\LyricsTrayBlocker.exe" status
pause
