@echo off
chcp 65001 >nul
set "ROOT=%~dp0"

"%ROOT%bin\LyricsTrayBlocker.exe" status
echo.
echo Current-user Run entry:
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Run -Name LyricsTrayNativeHook -ErrorAction SilentlyContinue | Select-Object -ExpandProperty LyricsTrayNativeHook"
echo.
echo Logon scheduled task:
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ScheduledTask -TaskName LyricsTrayNativeHook -ErrorAction SilentlyContinue | Select-Object TaskName,State | Format-Table -AutoSize"
pause
