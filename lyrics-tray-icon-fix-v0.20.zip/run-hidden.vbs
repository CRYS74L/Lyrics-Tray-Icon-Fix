Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
root = fso.GetParentFolderName(WScript.ScriptFullName)
exe = root & "\bin\LyricsTrayBlocker.exe"
shell.Run """" & exe & """ start", 0, False
