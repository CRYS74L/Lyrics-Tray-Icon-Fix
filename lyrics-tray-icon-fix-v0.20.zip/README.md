# Lyrics Tray Icon Fix

用于隐藏 BetterLyrics 和 Lyricify Lite 在 Windows 11 托盘中错误多出来的 `H.NotifyIcon_*` 图标。

这个项目是为个人用途编写的，只针对我自己机器上已经确认的问题场景。它不是通用托盘管理器，也不是 PS Tray Factory 的替代品。

当前稳定版本：

```text
v0.20-target-self-delete-hnotify
```

这是实际确认可用的版本。后续修改应避免破坏 v0.20 的行为。

## 解决什么问题

在某些环境下，BetterLyrics 和 Lyricify Lite 会各自额外显示一个错误托盘图标。PS Tray Factory 可以管理很多托盘图标，但对这两个软件的错误 `H.NotifyIcon_*` 图标不能稳定做到跨重启隐藏。

本工具只针对下面两个规则：

```text
LYRICIFY LITE.EXE + H.NotifyIcon_* + UID=0
BETTERLYRICS.WINUI3.EXE + H.NotifyIcon_* + UID=0
```

它会尽量只隐藏错误多出来的图标，保留同软件正常显示的托盘图标。

## 下载和使用

从 Releases 下载 `lyrics-tray-icon-fix-v0.20.zip`，解压到一个固定目录后，双击：

```text
Install and start v0.20.cmd
```

它会：

1. 写入当前 Windows 用户的开机启动项。
2. 启动后台服务。
3. 在当前用户登录后自动生效。

查看状态：

```text
Status v0.20.cmd
```

停止并移除开机启动：

```text
Stop and disable v0.20.cmd
```

## 重启后是否生效

会生效。

启动链路是：

```text
HKCU Run -> wscript.exe -> run-hidden.vbs -> bin\LyricsTrayBlocker.exe start
```

准确地说，是重启电脑并登录当前 Windows 用户后自动运行。托盘图标属于用户会话，未登录前不需要也不会运行。

## 必需文件

运行时必须保留：

```text
bin\LyricsTrayBlocker.exe
bin\LyricsTrayHook_v20.dll
run-hidden.vbs
```

安装和管理脚本：

```text
Install and start v0.20.cmd
Status v0.20.cmd
Stop and disable v0.20.cmd
install-startup-admin.ps1
install-task.ps1
uninstall-task.ps1
```

`src` 和 `tests` 是源码与规则测试备份，普通使用不需要手动运行。

## 性能和实现方式

本工具不是轮询实现。

它使用 Windows 消息 Hook：

```text
WH_CALLWNDPROC
WH_GETMESSAGE
```

后台控制进程主要等待事件，不持续扫描托盘。此前实测空闲时：

```text
LyricsTrayBlocker 10 秒 CPU 增量为 0
PSTrayFactory     10 秒 CPU 增量为 0
LyricsTrayBlocker 工作集约 10 MB
```

DLL 会被加载到多个 GUI 进程中，这是全局消息 Hook 的正常行为。非目标进程会快速返回，实际处理只针对 BetterLyrics 和 Lyricify Lite。

## 和 PS Tray Factory 的关系

本工具不替代 PS Tray Factory，只补足它对这两个错误图标处理不稳定的问题。

v0.20 不主动刷新 PS Tray Factory 的托盘列表，不广播 `PSTF_TRAY_READED`，也不发送 `PSTF_ReadTray`。这样可以避免冲掉 PS Tray Factory 中已经自定义的托盘图标图片。

## 安全说明

本工具不读取游戏内存，不扫描进程内存，不注入游戏专用逻辑。

它会安装全局 Windows 消息 Hook，因此 `LyricsTrayHook_v20.dll` 会出现在多个 GUI 进程的模块列表中。这一点和 PS Tray Factory 的实现路线类似。

如果特别在意游戏反作弊风险，请在启动相关游戏前自行评估是否停用本工具。

## 构建

仓库中包含源码和 `build.ps1`，但普通使用不需要重新构建。

原始构建环境使用 Zig C 编译器。重新构建需要在工作区提供：

```text
tools\zig\zig.exe
```

然后运行：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\build.ps1
```

## 开源协议

本项目使用 MIT License。
